(function () {
  "use strict";

  const isLocal = ["localhost", "127.0.0.1"].includes(window.location.hostname);
  window.PUBLICDROP_CONFIG = Object.freeze({
    IS_LOCAL: isLocal,
    TMDB_BASE_URL: "https://api.themoviedb.org/3",
    TMDB_API_KEY: "16f62d38fec24f4e6c2adc9388da20ce",
    API_RELAY_BASE_URL: `${window.location.origin}/api`,
    ANIMEX_RELAY_BASE_URL: `${window.location.origin}/api`,
    PYTHON_EMBED_BASE_URL: "https://vumeto.xyz",
    VUMETO_EMBED_BASE_URL: "https://vumeto.xyz",
    SERVER_ONE_EMBED_BASE_URL: "https://vidstuck.cc",
    PUBLICDROP_TV_ENABLED: false,
    // Keep Vidnest out of the Server 2 provider menu.
    VIDNEST_ENABLED: false,
    SUPABASE_URL: "https://gdpfxkobhyhwbhpaiuqr.supabase.co",
    SUPABASE_PUBLISHABLE_KEY: "sb_publishable_psyNZGl9aZOWpK_n_Ul2HQ_8wbVAsYT",
    IMAGE_BASE_URL: "https://image.tmdb.org/t/p",
    CATALOG_REQUEST_TIMEOUT_MS: 15000,
    DEFAULT_LANGUAGE: "en",
  });
})();
